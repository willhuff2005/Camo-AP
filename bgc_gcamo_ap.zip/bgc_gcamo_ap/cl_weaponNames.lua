AddTextEntry("weapon_bgc_gcamo_ap", "bgc_gcamo_ap")
